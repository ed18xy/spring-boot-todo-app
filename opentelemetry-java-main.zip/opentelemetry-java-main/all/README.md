# opentelemetry-all (utility project)

This is a utility project which depends on all other projects in this repository. We use it for
global checks, for example API checks with archunit, and collecting all coverage reports from all
modules for uploading to codecov.
