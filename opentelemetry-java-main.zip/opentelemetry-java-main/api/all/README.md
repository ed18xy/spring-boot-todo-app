# OpenTelemetry API

#### API Misuse Logging

API misuse information is logged under logger named `io.opentelemetry.ApiUsageLogging`.

To access, enable `FINEST` level logs.
