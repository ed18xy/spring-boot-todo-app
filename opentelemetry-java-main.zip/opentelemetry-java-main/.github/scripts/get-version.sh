#!/bin/bash -e

grep -Eo "[0-9]+.[0-9]+.[0-9]+" version.gradle.kts
