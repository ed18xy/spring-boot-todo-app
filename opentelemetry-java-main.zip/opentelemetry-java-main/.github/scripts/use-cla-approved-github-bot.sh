#!/bin/bash -e

git config user.name opentelemetrybot
git config user.email 107717825+opentelemetrybot@users.noreply.github.com
