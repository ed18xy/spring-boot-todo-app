# OpenTelemetry Quickstart

The quickstart has moved to [Manual instrumentation][] under [opentelemetry.io](https://opentelemetry.io).

[Manual instrumentation]: https://opentelemetry.io/docs/instrumentation/java/manual_instrumentation/
